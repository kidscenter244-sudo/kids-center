import React, { useState } from 'react';
import { ShoppingBag, Sparkles, Check, Heart, Shield, Lock } from 'lucide-react';
import { ShopItem, StudentProfile } from '../../types';
import { sounds } from '../../services/soundEffects';
import { RobloxCharacter } from '../RobloxCharacter';

interface ShopViewProps {
  items: ShopItem[];
  profile: StudentProfile;
  purchasedItemIds: string[];
  onBuyItem: (item: ShopItem) => void;
  onEquipItem: (item: ShopItem) => void;
}

export const ShopView: React.FC<ShopViewProps> = ({
  items,
  profile,
  purchasedItemIds,
  onBuyItem,
  onEquipItem,
}) => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'hat' | 'powerup'>('all');

  const filteredItems = activeCategory === 'all'
    ? items
    : items.filter((i) => i.category === activeCategory);

  return (
    <div className="max-w-4xl mx-auto p-3 sm:p-6 pb-24 text-left select-none">
      {/* Header with Balances & Roblox Character Preview */}
      <div className="bg-gradient-to-r from-purple-700 via-indigo-700 to-blue-700 rounded-3xl p-5 sm:p-8 text-white shadow-xl mb-6 relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 sm:w-22 sm:h-22 rounded-2xl bg-white/15 backdrop-blur-md border-2 border-white/30 flex items-center justify-center p-1 shadow-inner shrink-0">
              <RobloxCharacter
                name={profile.name}
                gender={profile.gender}
                equippedHat={profile.equippedHat}
                size="md"
              />
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-white/20 backdrop-blur-xs text-[11px] sm:text-xs font-black uppercase tracking-wider mb-1">
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>Roblox Gear & Power-ups</span>
              </div>
              <h1 className="font-heading font-black text-2xl sm:text-3xl leading-tight">
                Roblox Customization Shop
              </h1>
              <p className="text-white/85 text-xs sm:text-sm font-semibold mt-0.5">
                Earn coins in 50-question exams to unlock headgear and energy hearts!
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 bg-black/25 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-white/20 shrink-0">
            <div className="flex items-center gap-1.5">
              <span className="text-xl">🪙</span>
              <span className="font-heading font-black text-lg text-amber-300">{profile.coins}</span>
            </div>
            <div className="w-px h-6 bg-white/20" />
            <div className="flex items-center gap-1.5">
              <span className="text-xl">💎</span>
              <span className="font-heading font-black text-lg text-cyan-300">{profile.gems}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-1 no-scrollbar">
        {[
          { id: 'all', label: 'All Items' },
          { id: 'hat', label: 'Roblox Hats & Gear' },
          { id: 'powerup', label: 'Hearts & Power-ups' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => {
              sounds.playClick();
              setActiveCategory(tab.id as any);
            }}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-black whitespace-nowrap transition-all cursor-pointer ${
              activeCategory === tab.id
                ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Items Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {filteredItems.map((item) => {
          const isPurchased = purchasedItemIds.includes(item.id) || item.costCoins === 0;
          const isEquipped = profile.avatarId === item.id || profile.equippedHat === item.id;
          const canAfford = profile.coins >= item.costCoins && profile.gems >= item.costGems;

          return (
            <div
              key={item.id}
              className={`p-5 rounded-3xl bg-white border-2 flex flex-col justify-between transition-all ${
                isEquipped
                  ? 'border-emerald-500 shadow-md ring-2 ring-emerald-400/20'
                  : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <div>
                {/* Icon & Category Badge */}
                <div className="flex items-center justify-between mb-3">
                  <span className="text-4xl p-2 rounded-2xl bg-slate-50 border border-slate-100">{item.icon}</span>
                  <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                    {item.category === 'character' ? 'Avatar' : item.category === 'hat' ? 'Hat' : 'Power-up'}
                  </span>
                </div>

                <h3 className="font-heading font-black text-lg text-slate-800 mb-1">
                  {item.name}
                </h3>
                <p className="text-xs text-slate-500 font-semibold mb-4 leading-relaxed">
                  {item.description}
                </p>
              </div>

              {/* Price & Action Button */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                <div>
                  {isPurchased && item.isEquippable ? (
                    <span className="text-xs font-black text-emerald-600 flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" />
                      <span>Unlocked</span>
                    </span>
                  ) : (
                    <div className="flex items-center gap-1.5 font-black text-sm">
                      {item.costCoins > 0 && <span className="text-amber-600">{item.costCoins} 🪙</span>}
                      {item.costGems > 0 && <span className="text-cyan-600">+{item.costGems} 💎</span>}
                      {item.costCoins === 0 && item.costGems === 0 && (
                        <span className="text-emerald-600">Free Starter</span>
                      )}
                    </div>
                  )}
                </div>

                {item.isEquippable ? (
                  isPurchased ? (
                    <button
                      onClick={() => {
                        sounds.playClick();
                        onEquipItem(item);
                      }}
                      className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${
                        isEquipped
                          ? 'bg-emerald-500 text-white shadow-xs'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                      }`}
                    >
                      {isEquipped ? 'Equipped' : 'Equip'}
                    </button>
                  ) : (
                    <button
                      disabled={!canAfford}
                      onClick={() => {
                        sounds.playCorrect();
                        onBuyItem(item);
                      }}
                      className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 disabled:opacity-40 text-white font-black text-xs uppercase shadow-[0_3px_0_#6b21a8] cursor-pointer"
                    >
                      Buy
                    </button>
                  )
                ) : (
                  /* Single use power-up like Heart Refill */
                  <button
                    disabled={!canAfford}
                    onClick={() => {
                      sounds.playCorrect();
                      onBuyItem(item);
                    }}
                    className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 disabled:opacity-40 text-white font-black text-xs uppercase shadow-[0_3px_0_#d97706] cursor-pointer"
                  >
                    Use (40 🪙)
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
