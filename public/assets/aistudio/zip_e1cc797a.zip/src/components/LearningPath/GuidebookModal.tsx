import React from 'react';
import { BookOpen, X, Sparkles, Lightbulb, CheckCircle2 } from 'lucide-react';
import { Unit } from '../../types';
import { sounds } from '../../services/soundEffects';

interface GuidebookModalProps {
  unit: Unit;
  onClose: () => void;
}

export const GuidebookModal: React.FC<GuidebookModalProps> = ({ unit, onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-lg w-full max-h-[85vh] flex flex-col shadow-2xl border-2 border-slate-200 overflow-hidden text-left">
        {/* Modal Header */}
        <div className={`p-4 sm:p-5 text-white ${unit.colorScheme.bannerBg} flex items-center justify-between`}>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <div>
              <span className="text-[10px] sm:text-xs uppercase font-black tracking-widest text-white/80">Unit {unit.number} Rules Guidebook</span>
              <h3 className="font-heading font-black text-lg sm:text-xl leading-tight">{unit.title}</h3>
            </div>
          </div>

          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="p-1.5 rounded-xl bg-black/20 hover:bg-black/30 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5">
          {/* Summary */}
          <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-500 mb-2 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>Unit Overview</span>
            </h4>
            <p className="text-slate-700 text-xs sm:text-sm font-bold leading-relaxed">
              {unit.guidebook.summary}
            </p>
          </div>

          {/* Key Concepts */}
          <div>
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-500 mb-3 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <span>Golden Exam Rules (50 Questions)</span>
            </h4>
            <div className="space-y-2.5">
              {unit.guidebook.keyPoints.map((point, idx) => (
                <div key={idx} className="flex items-start gap-3 p-3 rounded-xl bg-emerald-50/70 border border-emerald-100">
                  <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center text-xs font-black shrink-0 mt-0.5">
                    {idx + 1}
                  </div>
                  <p className="text-xs sm:text-sm font-bold text-slate-800 leading-snug">
                    {point}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Expert Tips */}
          <div>
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-500 mb-3 flex items-center gap-1.5">
              <Lightbulb className="w-4 h-4 text-amber-500" />
              <span>Mental Speed & Focus Tips</span>
            </h4>
            <div className="space-y-2">
              {unit.guidebook.tips.map((tip, idx) => (
                <div key={idx} className="flex items-start gap-2.5 p-3 rounded-xl bg-amber-50/70 border border-amber-200/80">
                  <span className="text-base shrink-0">💡</span>
                  <p className="text-xs sm:text-sm text-amber-950 font-bold leading-relaxed">
                    {tip}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50">
          <button
            onClick={() => {
              sounds.playClick();
              onClose();
            }}
            className="w-full py-3 rounded-2xl bg-slate-800 hover:bg-slate-900 text-white font-black text-sm tracking-wide shadow-md transition-all cursor-pointer"
          >
            Understood! Let's Begin Training
          </button>
        </div>
      </div>
    </div>
  );
};
