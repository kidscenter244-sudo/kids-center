import React from 'react';
import { BookOpen, ChevronLeft, ChevronRight, CheckCircle2 } from 'lucide-react';
import { Unit } from '../../types';
import { sounds } from '../../services/soundEffects';

interface UnitHeaderProps {
  unit: Unit;
  units: Unit[];
  completedCount: number;
  totalLessons: number;
  onSelectUnit: (unit: Unit) => void;
  onOpenGuidebook: () => void;
}

export const UnitHeader: React.FC<UnitHeaderProps> = ({
  unit,
  units,
  completedCount,
  totalLessons,
  onSelectUnit,
  onOpenGuidebook,
}) => {
  const currentIndex = units.findIndex((u) => u.id === unit.id);
  const prevUnit = currentIndex > 0 ? units[currentIndex - 1] : null;
  const nextUnit = currentIndex < units.length - 1 ? units[currentIndex + 1] : null;

  const progressPercent = Math.round((completedCount / Math.max(totalLessons, 1)) * 100);
  const isUnitFinished = completedCount === totalLessons && totalLessons > 0;

  return (
    <div className="w-full max-w-xl mx-auto mb-6 px-3 sm:px-4">
      {/* Unit Banner */}
      <div className={`relative overflow-hidden rounded-3xl ${unit.colorScheme.bannerBg} text-white p-4 sm:p-6 shadow-xl border-2 border-white/20 transition-all text-left`}>
        {/* Decorative background shapes */}
        <div className="absolute -top-12 -right-12 w-40 h-40 bg-white/10 rounded-full blur-xl pointer-events-none" />
        <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-black/10 rounded-full blur-lg pointer-events-none" />

        {/* Top Header Row with Unit Switchers */}
        <div className="relative z-10 flex items-center justify-between gap-2 mb-2 sm:mb-3">
          <div className="flex items-center gap-1.5 bg-black/25 backdrop-blur-xs px-3 py-1 rounded-full text-[11px] sm:text-xs font-black uppercase tracking-wider">
            <span>Unit {unit.number} of {units.length}</span>
            {isUnitFinished && (
              <CheckCircle2 className="w-4 h-4 text-emerald-300 ml-1 inline" />
            )}
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => {
                if (prevUnit) {
                  sounds.playClick();
                  onSelectUnit(prevUnit);
                }
              }}
              disabled={!prevUnit}
              className={`p-1.5 rounded-xl bg-black/20 hover:bg-black/30 transition-all ${
                !prevUnit ? 'opacity-30 cursor-not-allowed' : 'cursor-pointer active:scale-95'
              }`}
              title="Previous Unit"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                if (nextUnit) {
                  sounds.playClick();
                  onSelectUnit(nextUnit);
                }
              }}
              disabled={!nextUnit}
              className={`p-1.5 rounded-xl bg-black/20 hover:bg-black/30 transition-all ${
                !nextUnit ? 'opacity-30 cursor-not-allowed' : 'cursor-pointer active:scale-95'
              }`}
              title="Next Unit"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Unit Title and Description */}
        <div className="relative z-10 mb-3 sm:mb-4">
          <h2 className="font-heading font-black text-xl sm:text-2xl leading-tight drop-shadow-sm mb-1">
            {unit.title}
          </h2>
          <p className="text-white/90 text-xs sm:text-sm font-semibold line-clamp-2">
            {unit.description}
          </p>
        </div>

        {/* Progress bar & Guidebook CTA */}
        <div className="relative z-10 flex items-center justify-between gap-2.5 pt-2 border-t border-white/20">
          <div className="flex-1 mr-3">
            <div className="flex items-center justify-between text-[11px] font-black uppercase tracking-wider mb-1 text-white/90">
              <span>{completedCount}/{totalLessons} Lessons Mastered</span>
              <span>{progressPercent}%</span>
            </div>
            <div className="w-full h-2.5 bg-black/30 rounded-full overflow-hidden p-0.5 border border-white/20">
              <div
                className="h-full bg-amber-400 rounded-full transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          <button
            onClick={() => {
              sounds.playClick();
              onOpenGuidebook();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white text-slate-800 hover:bg-amber-50 font-black text-xs uppercase tracking-wider shadow-md hover:scale-105 active:scale-95 transition-all cursor-pointer shrink-0"
          >
            <BookOpen className="w-3.5 h-3.5 text-amber-500" />
            <span>Guidebook</span>
          </button>
        </div>
      </div>
    </div>
  );
};
