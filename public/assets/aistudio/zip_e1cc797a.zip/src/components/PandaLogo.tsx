import React from 'react';

interface PandaLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  className?: string;
  animate?: boolean;
  mood?: 'happy' | 'excited' | 'thinking' | 'sad';
}

export const PandaLogo: React.FC<PandaLogoProps> = ({
  size = 'md',
  className = '',
  animate = true,
  mood = 'happy',
}) => {
  const sizeMap = {
    sm: 'w-8 h-8',
    md: 'w-12 h-12',
    lg: 'w-20 h-20',
    xl: 'w-28 h-28',
    '2xl': 'w-36 h-36',
  };

  return (
    <div
      className={`relative inline-flex items-center justify-center shrink-0 ${sizeMap[size]} ${className}`}
      aria-label="Panda Mascot"
    >
      <svg
        viewBox="0 0 120 120"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`w-full h-full drop-shadow-md transition-transform duration-300 ${
          animate ? 'hover:scale-105 active:scale-95' : ''
        }`}
      >
        <defs>
          {/* Subtle 3D gradient for body */}
          <linearGradient id="pandaFaceGrad" x1="60" y1="20" x2="60" y2="105" gradientUnits="userSpaceOnUse">
            <stop stopColor="#FFFFFF" />
            <stop offset="0.85" stopColor="#F8FAFC" />
            <stop offset="1" stopColor="#E2E8F0" />
          </linearGradient>

          <linearGradient id="pandaEarGrad" x1="25" y1="10" x2="25" y2="45" gradientUnits="userSpaceOnUse">
            <stop stopColor="#1E293B" />
            <stop offset="1" stopColor="#0F172A" />
          </linearGradient>

          <linearGradient id="bambooGrad" x1="0" y1="0" x2="0" y2="40" gradientUnits="userSpaceOnUse">
            <stop stopColor="#22C55E" />
            <stop offset="1" stopColor="#15803D" />
          </linearGradient>
        </defs>

        {/* --- Ears --- */}
        {/* Left Ear */}
        <circle cx="28" cy="30" r="18" fill="url(#pandaEarGrad)" />
        <circle cx="28" cy="30" r="10" fill="#334155" />

        {/* Right Ear */}
        <circle cx="92" cy="30" r="18" fill="url(#pandaEarGrad)" />
        <circle cx="92" cy="30" r="10" fill="#334155" />

        {/* --- Head Base --- */}
        <rect
          x="16"
          y="24"
          width="88"
          height="82"
          rx="41"
          fill="url(#pandaFaceGrad)"
          stroke="#0F172A"
          strokeWidth="4"
        />

        {/* --- Eye Patches (Signature Black Panda Patches) --- */}
        {/* Left Eye Patch */}
        <ellipse
          cx="40"
          cy="58"
          rx="15"
          ry="19"
          transform="rotate(-15 40 58)"
          fill="#0F172A"
        />
        {/* Right Eye Patch */}
        <ellipse
          cx="80"
          cy="58"
          rx="15"
          ry="19"
          transform="rotate(15 80 58)"
          fill="#0F172A"
        />

        {/* --- Eyes & Pupils --- */}
        {mood === 'sad' ? (
          <>
            {/* Sad / Teary Eyes */}
            <path d="M34 56 Q40 52 46 56" stroke="#FFFFFF" strokeWidth="3" strokeLinecap="round" />
            <path d="M74 56 Q80 52 86 56" stroke="#FFFFFF" strokeWidth="3" strokeLinecap="round" />
            {/* Tear droplet */}
            <circle cx="36" cy="65" r="3" fill="#38BDF8" />
          </>
        ) : mood === 'excited' ? (
          <>
            {/* Starry / Sparkly Happy Eyes */}
            <circle cx="41" cy="57" r="7" fill="#FFFFFF" />
            <circle cx="41" cy="57" r="4.5" fill="#0284C7" />
            <circle cx="39" cy="55" r="2" fill="#FFFFFF" />

            <circle cx="79" cy="57" r="7" fill="#FFFFFF" />
            <circle cx="79" cy="57" r="4.5" fill="#0284C7" />
            <circle cx="77" cy="55" r="2" fill="#FFFFFF" />
          </>
        ) : (
          <>
            {/* Standard Big Friendly Panda Eyes */}
            <circle cx="41" cy="57" r="7.5" fill="#FFFFFF" />
            <circle cx="42" cy="57" r="4.5" fill="#0F172A" />
            <circle cx="40" cy="55" r="2" fill="#FFFFFF" />

            <circle cx="79" cy="57" r="7.5" fill="#FFFFFF" />
            <circle cx="78" cy="57" r="4.5" fill="#0F172A" />
            <circle cx="76" cy="55" r="2" fill="#FFFFFF" />
          </>
        )}

        {/* --- Pink Rosy Cheeks --- */}
        <circle cx="26" cy="74" r="7" fill="#FDA4AF" opacity="0.75" />
        <circle cx="94" cy="74" r="7" fill="#FDA4AF" opacity="0.75" />

        {/* --- Panda Nose --- */}
        <ellipse cx="60" cy="68" rx="7.5" ry="5" fill="#0F172A" />
        <circle cx="58" cy="67" r="1.5" fill="#FFFFFF" opacity="0.6" />

        {/* --- Mouth --- */}
        {mood === 'sad' ? (
          <path
            d="M52 82 Q60 76 68 82"
            stroke="#0F172A"
            strokeWidth="3.5"
            strokeLinecap="round"
          />
        ) : mood === 'excited' ? (
          <path
            d="M50 75 Q60 92 70 75 Z"
            fill="#EF4444"
            stroke="#0F172A"
            strokeWidth="3"
            strokeLinejoin="round"
          />
        ) : (
          <path
            d="M52 75 Q60 84 68 75"
            stroke="#0F172A"
            strokeWidth="3.5"
            strokeLinecap="round"
          />
        )}

        {/* --- Green Bamboo Sprig on Forehead / Ear --- */}
        <g transform="translate(74, 18) rotate(18)">
          <path
            d="M10 25 C10 15, 20 8, 25 5 C22 15, 18 22, 10 25 Z"
            fill="url(#bambooGrad)"
            stroke="#14532D"
            strokeWidth="1.5"
          />
          <path
            d="M10 25 C5 18, 2 12, 0 8 C6 14, 8 20, 10 25 Z"
            fill="#4ADE80"
            stroke="#14532D"
            strokeWidth="1"
          />
        </g>
      </svg>
    </div>
  );
};
