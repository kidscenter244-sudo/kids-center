import React from 'react';

interface CuteBearLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  className?: string;
  animate?: boolean;
  mood?: 'happy' | 'excited' | 'thinking' | 'sad';
}

export const CuteBearLogo: React.FC<CuteBearLogoProps> = ({
  size = 'md',
  className = '',
  animate = true,
  mood = 'happy',
}) => {
  const sizeMap = {
    sm: 'w-9 h-9',
    md: 'w-12 h-12',
    lg: 'w-20 h-20',
    xl: 'w-28 h-28',
    '2xl': 'w-36 h-36',
  };

  return (
    <div
      className={`relative inline-flex items-center justify-center shrink-0 ${sizeMap[size]} ${className}`}
      aria-label="Cute Bear Mascot"
    >
      <svg
        viewBox="0 0 120 120"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`w-full h-full drop-shadow-md transition-transform duration-300 ${
          animate ? 'hover:scale-105 active:scale-95' : ''
        }`}
      >
        <defs>
          {/* Bear Body Fur Gradient - Warm honey golden brown */}
          <linearGradient id="bearFurGrad" x1="60" y1="20" x2="60" y2="105" gradientUnits="userSpaceOnUse">
            <stop stopColor="#FDBA74" />
            <stop offset="0.3" stopColor="#FB923C" />
            <stop offset="1" stopColor="#EA580C" />
          </linearGradient>

          {/* Soft inner ear gradient */}
          <linearGradient id="bearInnerEarGrad" x1="0" y1="0" x2="0" y2="1">
            <stop stopColor="#FECDD3" />
            <stop offset="1" stopColor="#FDA4AF" />
          </linearGradient>

          {/* Muzzle gradient */}
          <linearGradient id="muzzleGrad" x1="60" y1="58" x2="60" y2="90" gradientUnits="userSpaceOnUse">
            <stop stopColor="#FFFBEB" />
            <stop offset="1" stopColor="#FEF3C7" />
          </linearGradient>

          {/* 3D Gloss highlight */}
          <linearGradient id="headGloss" x1="40" y1="26" x2="60" y2="48" gradientUnits="userSpaceOnUse">
            <stop stopColor="#FFFFFF" stopOpacity="0.45" />
            <stop offset="1" stopColor="#FFFFFF" stopOpacity="0" />
          </linearGradient>
        </defs>

        {/* --- Rounded Fluffy Ears --- */}
        {/* Left Ear */}
        <circle cx="28" cy="30" r="17" fill="url(#bearFurGrad)" stroke="#9A3412" strokeWidth="3" />
        <circle cx="28" cy="30" r="10" fill="url(#bearInnerEarGrad)" />

        {/* Right Ear */}
        <circle cx="92" cy="30" r="17" fill="url(#bearFurGrad)" stroke="#9A3412" strokeWidth="3" />
        <circle cx="92" cy="30" r="10" fill="url(#bearInnerEarGrad)" />

        {/* --- Cute Round Bear Head --- */}
        <rect
          x="16"
          y="24"
          width="88"
          height="82"
          rx="41"
          fill="url(#bearFurGrad)"
          stroke="#9A3412"
          strokeWidth="3.5"
        />

        {/* Gloss highlight on top-left of forehead */}
        <ellipse cx="45" cy="36" rx="18" ry="8" transform="rotate(-15 45 36)" fill="url(#headGloss)" />

        {/* Little tuft of hair on top */}
        <path
          d="M56 24 C57 18, 62 16, 64 20 C66 17, 70 19, 69 24 Z"
          fill="#EA580C"
          stroke="#9A3412"
          strokeWidth="2"
        />

        {/* --- Big Adorable Kawaii Eyes --- */}
        {mood === 'sad' ? (
          <>
            {/* Sad / Teary eyes */}
            <circle cx="39" cy="57" r="8" fill="#1E293B" />
            <circle cx="81" cy="57" r="8" fill="#1E293B" />
            {/* Gloss sparkles */}
            <circle cx="37" cy="54" r="3.2" fill="#FFFFFF" />
            <circle cx="79" cy="54" r="3.2" fill="#FFFFFF" />
            {/* Blue tears */}
            <circle cx="34" cy="67" r="3.5" fill="#38BDF8" />
            <path d="M34 62 L32 67 L36 67 Z" fill="#38BDF8" />
          </>
        ) : mood === 'excited' ? (
          <>
            {/* Super happy starry anime eyes */}
            <circle cx="39" cy="57" r="9.5" fill="#0F172A" />
            <circle cx="81" cy="57" r="9.5" fill="#0F172A" />
            {/* Star sparkle highlights */}
            <circle cx="37" cy="53" r="4.2" fill="#FFFFFF" />
            <circle cx="43" cy="61" r="2" fill="#FFFFFF" />
            <circle cx="79" cy="53" r="4.2" fill="#FFFFFF" />
            <circle cx="85" cy="61" r="2" fill="#FFFFFF" />
            {/* Sparkle stars */}
            <polygon points="39,47 40.5,50 43,50 41,51.5 42,54 39,52.5 36,54 37,51.5 35,50 37.5,50" fill="#FDE047" />
          </>
        ) : (
          <>
            {/* Normal Ultra-Cute Shiny Bear Eyes */}
            <ellipse cx="39" cy="57" rx="8.5" ry="9" fill="#0F172A" />
            <ellipse cx="81" cy="57" rx="8.5" ry="9" fill="#0F172A" />
            {/* Big glossy main catchlight */}
            <ellipse cx="36.5" cy="53.5" rx="3.8" ry="4" fill="#FFFFFF" />
            <ellipse cx="78.5" cy="53.5" rx="3.8" ry="4" fill="#FFFFFF" />
            {/* Secondary cute bottom shine */}
            <circle cx="42" cy="61" r="2.2" fill="#FFFFFF" />
            <circle cx="84" cy="61" r="2.2" fill="#FFFFFF" />
          </>
        )}

        {/* --- Cute Rosy Blush Cheeks --- */}
        <ellipse cx="26" cy="71" rx="8.5" ry="6" fill="#FDA4AF" opacity="0.85" />
        <ellipse cx="94" cy="71" rx="8.5" ry="6" fill="#FDA4AF" opacity="0.85" />
        {/* Blush glow lines */}
        <line x1="23" y1="69" x2="29" y2="73" stroke="#F43F5E" strokeWidth="1.2" strokeLinecap="round" opacity="0.6" />
        <line x1="91" y1="69" x2="97" y2="73" stroke="#F43F5E" strokeWidth="1.2" strokeLinecap="round" opacity="0.6" />

        {/* --- Soft Cream Muzzle --- */}
        <ellipse cx="60" cy="72" rx="17" ry="13" fill="url(#muzzleGrad)" stroke="#CA8A04" strokeWidth="1.5" />

        {/* Little Heart/Round Bear Nose */}
        <path
          d="M55 67 C55 64, 58 63, 60 65 C62 63, 65 64, 65 67 C65 70, 60 73, 60 73 C60 73, 55 70, 55 67 Z"
          fill="#451A03"
        />
        {/* Nose shine */}
        <circle cx="58" cy="66" r="1.2" fill="#FFFFFF" opacity="0.8" />

        {/* --- Cute Smile --- */}
        {mood === 'sad' ? (
          <path
            d="M54 81 Q60 75 66 81"
            stroke="#451A03"
            strokeWidth="2.8"
            strokeLinecap="round"
          />
        ) : mood === 'excited' ? (
          <path
            d="M53 74 Q60 88 67 74 Z"
            fill="#EF4444"
            stroke="#451A03"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />
        ) : (
          <path
            d="M53 74 Q60 81 67 74"
            stroke="#451A03"
            strokeWidth="2.8"
            strokeLinecap="round"
          />
        )}

        {/* --- Tiny Green Math Wizard Bow Tie / Leaf --- */}
        <g transform="translate(60, 99)">
          {/* Green Bow Tie */}
          <polygon points="0,0 -14,-7 -14,7" fill="#22C55E" stroke="#15803D" strokeWidth="1.5" />
          <polygon points="0,0 14,-7 14,7" fill="#22C55E" stroke="#15803D" strokeWidth="1.5" />
          <circle cx="0" cy="0" r="4.5" fill="#EAB308" stroke="#CA8A04" strokeWidth="1" />
        </g>
      </svg>
    </div>
  );
};

// Re-export as PandaLogo alias so any legacy imports continue to function
export const PandaLogo = CuteBearLogo;
