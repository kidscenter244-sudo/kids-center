import React from 'react';

/**
 * Intelligent gender detection from Arabic and English student names.
 * If feminine indicators are found, returns 'girl'; otherwise defaults to 'boy'.
 */
export function detectGenderFromName(name: string): 'boy' | 'girl' {
  if (!name || typeof name !== 'string') return 'boy';

  const clean = name.trim().toLowerCase();

  // Common Arabic and English female names
  const knownGirlNames = new Set([
    // Arabic names
    'مريم', 'سارة', 'ساره', 'فاطمة', 'فاطمه', 'نور', 'نورا', 'نوره', 'ياسمين', 'ليلى', 'ليلي',
    'ملك', 'فريدة', 'فريده', 'جنا', 'جنى', 'سلمى', 'سلمي', 'روان', 'حنين', 'ريم', 'شهد',
    'آية', 'ايه', 'حبيبة', 'حبيبه', 'رنا', 'هنا', 'منة', 'منه', 'دينا', 'إسراء', 'اسراء',
    'مي', 'هدى', 'هدي', 'زينب', 'خديجة', 'خديجه', 'روان', 'تاليا', 'كارما', 'تيا', 'لارا',
    'كنزي', 'ندى', 'ندي', 'بسملة', 'بسمله', 'رودينا', 'ريتاج', 'جودي',
    // English names
    'maya', 'emma', 'sarah', 'sara', 'maryam', 'fatima', 'fatma', 'lily', 'sophia', 'chloe',
    'nora', 'norah', 'layla', 'laila', 'salma', 'hana', 'yasmin', 'yasmine', 'jessica', 'olivia',
    'emily', 'ava', 'isabella', 'mia', 'charlotte', 'amelia', 'harper', 'evelyn', 'abigail',
    'ella', 'elizabeth', 'camila', 'luna', 'sofia', 'avery', 'mila', 'aria', 'scarlett',
    'penelope', 'riley', 'zoey', 'grace', 'hannah', 'chloe', 'victoria', 'zoe', 'stella',
    'leah', 'hazel', 'ellie', 'violet', 'aurora', 'savannah', 'audrey', 'brooklyn', 'bella',
    'claire', 'skylar', 'lucy', 'paisley', 'everly', 'anna', 'caroline', 'nova', 'genesis',
    'aaliyah', 'kennedy', 'kinsley', 'allison', 'maya', 'alyssa', 'madelyn', 'alice', 'julie',
  ]);

  // First name extraction
  const firstName = clean.split(/[\s_]+/)[0];

  if (knownGirlNames.has(firstName) || knownGirlNames.has(clean)) {
    return 'girl';
  }

  // Common feminine endings in Arabic and English
  if (
    clean.endsWith('ة') || 
    clean.endsWith('ه') || 
    clean.endsWith('اء') || 
    clean.endsWith('ينا') ||
    clean.endsWith('line') ||
    clean.endsWith('ette') ||
    clean.endsWith('anna') ||
    clean.endsWith('bella') ||
    clean.endsWith('ella')
  ) {
    return 'girl';
  }

  return 'boy';
}

interface RobloxCharacterProps {
  name?: string;
  gender?: 'boy' | 'girl';
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  className?: string;
  equippedHat?: string;
  showTorso?: boolean;
}

export const RobloxCharacter: React.FC<RobloxCharacterProps> = ({
  name = 'Player',
  gender,
  size = 'md',
  className = '',
  equippedHat,
  showTorso = true,
}) => {
  // Automatically detect gender from name unless explicitly passed
  const resolvedGender: 'boy' | 'girl' = gender || detectGenderFromName(name);
  const isGirl = resolvedGender === 'girl';

  const sizeMap = {
    sm: 'w-10 h-10',
    md: 'w-14 h-14',
    lg: 'w-20 h-20',
    xl: 'w-28 h-28',
    '2xl': 'w-36 h-36',
  };

  return (
    <div
      className={`relative inline-flex items-center justify-center shrink-0 select-none ${sizeMap[size]} ${className}`}
      aria-label={`Roblox ${isGirl ? 'Girl' : 'Boy'} Character`}
    >
      <svg
        viewBox="0 0 120 140"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full drop-shadow-md transition-transform duration-200 hover:scale-105"
      >
        <defs>
          {/* Roblox Classic Yellow Skin Tone */}
          <linearGradient id="robloxSkin" x1="60" y1="20" x2="60" y2="70" gradientUnits="userSpaceOnUse">
            <stop stopColor="#FACC15" />
            <stop offset="1" stopColor="#EAB308" />
          </linearGradient>

          {/* Boy Shirt Gradient - Emerald / Cyan Gamer Hoodie */}
          <linearGradient id="boyShirt" x1="60" y1="70" x2="60" y2="135" gradientUnits="userSpaceOnUse">
            <stop stopColor="#10B981" />
            <stop offset="1" stopColor="#047857" />
          </linearGradient>

          {/* Girl Shirt Gradient - Pastel Pink / Purple Star Hoodie */}
          <linearGradient id="girlShirt" x1="60" y1="70" x2="60" y2="135" gradientUnits="userSpaceOnUse">
            <stop stopColor="#F472B6" />
            <stop offset="1" stopColor="#DB2777" />
          </linearGradient>

          {/* Boy Hair Gradient */}
          <linearGradient id="boyHair" x1="60" y1="12" x2="60" y2="45" gradientUnits="userSpaceOnUse">
            <stop stopColor="#451A03" />
            <stop offset="1" stopColor="#1C1917" />
          </linearGradient>

          {/* Girl Hair Gradient */}
          <linearGradient id="girlHair" x1="60" y1="10" x2="60" y2="85" gradientUnits="userSpaceOnUse">
            <stop stopColor="#78350F" />
            <stop offset="1" stopColor="#451A03" />
          </linearGradient>
        </defs>

        {/* ================= TORSO & ARMS (Roblox Classic Blocky R6 Body) ================= */}
        {showTorso && (
          <g id="robloxBody">
            {/* Left Arm (Blocky) */}
            <rect
              x="12"
              y="74"
              width="18"
              height="44"
              rx="4"
              fill={isGirl ? 'url(#girlShirt)' : 'url(#boyShirt)'}
              stroke="#0F172A"
              strokeWidth="2.5"
            />
            {/* Left Hand (Yellow Blocky Roblox Hand) */}
            <circle cx="21" cy="122" r="7" fill="url(#robloxSkin)" stroke="#0F172A" strokeWidth="2" />

            {/* Right Arm (Blocky) */}
            <rect
              x="90"
              y="74"
              width="18"
              height="44"
              rx="4"
              fill={isGirl ? 'url(#girlShirt)' : 'url(#boyShirt)'}
              stroke="#0F172A"
              strokeWidth="2.5"
            />
            {/* Right Hand (Yellow Blocky Roblox Hand) */}
            <circle cx="99" cy="122" r="7" fill="url(#robloxSkin)" stroke="#0F172A" strokeWidth="2" />

            {/* Main Rectangular Torso */}
            <rect
              x="32"
              y="70"
              width="56"
              height="58"
              rx="5"
              fill={isGirl ? 'url(#girlShirt)' : 'url(#boyShirt)'}
              stroke="#0F172A"
              strokeWidth="3"
            />

            {/* Torso Graphic Decal */}
            {isGirl ? (
              // Cute Star & Heart Math Decal for Girl
              <g>
                <circle cx="60" cy="94" r="12" fill="#FFFFFF" fillOpacity="0.25" />
                <path
                  d="M60 88 L62 93 L67 93 L63 96 L65 101 L60 98 L55 101 L57 96 L53 93 L58 93 Z"
                  fill="#FDF2F8"
                />
                {/* Cute collar line */}
                <path d="M48 70 Q60 80 72 70" stroke="#FFFFFF" strokeWidth="2.5" fill="none" />
              </g>
            ) : (
              // Cool Gamer / Soroban Ninja Graphic for Boy
              <g>
                <rect x="46" y="86" width="28" height="18" rx="3" fill="#0F172A" fillOpacity="0.3" />
                <path d="M52 95 L68 95" stroke="#34D399" strokeWidth="3" strokeLinecap="round" />
                <circle cx="60" cy="95" r="3" fill="#FACC15" />
                {/* Hoodie strings */}
                <path d="M48 70 Q60 78 72 70" stroke="#0F172A" strokeWidth="2.5" fill="none" />
                <line x1="56" y1="76" x2="56" y2="84" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" />
                <line x1="64" y1="76" x2="64" y2="84" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" />
              </g>
            )}
          </g>
        )}

        {/* ================= ROBLOX HEAD (Signature Blocky Cylinder) ================= */}
        <g id="robloxHead">
          {/* Top Stud (Signature Roblox Stud on Top of Head) */}
          <rect
            x="48"
            y="18"
            width="24"
            height="8"
            rx="3"
            fill="url(#robloxSkin)"
            stroke="#0F172A"
            strokeWidth="2.5"
          />

          {/* Main Blocky Head */}
          <rect
            x="34"
            y="24"
            width="52"
            height="46"
            rx="8"
            fill="url(#robloxSkin)"
            stroke="#0F172A"
            strokeWidth="3.5"
          />

          {/* ================= HAIR & ACCESSORIES ================= */}
          {isGirl ? (
            /* Girl Hair: Cute Long Ponytail / Flowing Brown/Caramel Hair with Ribbon */
            <g id="girlHairStyle">
              {/* Left & Right Long Hair Strands */}
              <rect x="28" y="32" width="10" height="48" rx="5" fill="url(#girlHair)" stroke="#0F172A" strokeWidth="2.5" />
              <rect x="82" y="32" width="10" height="48" rx="5" fill="url(#girlHair)" stroke="#0F172A" strokeWidth="2.5" />
              {/* Hair Bangs Top */}
              <rect x="33" y="20" width="54" height="15" rx="5" fill="url(#girlHair)" stroke="#0F172A" strokeWidth="2.5" />
              <path
                d="M34 26 Q46 36 60 26 Q74 36 86 26 L86 20 L34 20 Z"
                fill="url(#girlHair)"
              />
              {/* Cute Pink Bow / Clip */}
              <g transform="translate(80, 24)">
                <polygon points="0,0 -8,-5 -8,5" fill="#F43F5E" stroke="#0F172A" strokeWidth="1.5" />
                <polygon points="0,0 8,-5 8,5" fill="#F43F5E" stroke="#0F172A" strokeWidth="1.5" />
                <circle cx="0" cy="0" r="2.5" fill="#FEF08A" stroke="#0F172A" strokeWidth="1" />
              </g>
            </g>
          ) : (
            /* Boy Hair: Cool Blocky Spiky Hair */
            <g id="boyHairStyle">
              <rect x="33" y="19" width="54" height="13" rx="4" fill="url(#boyHair)" stroke="#0F172A" strokeWidth="2.5" />
              {/* Spiky Swoops */}
              <polygon points="36,22 44,14 50,22" fill="url(#boyHair)" stroke="#0F172A" strokeWidth="2" />
              <polygon points="48,22 58,12 66,22" fill="url(#boyHair)" stroke="#0F172A" strokeWidth="2" />
              <polygon points="64,22 74,15 82,22" fill="url(#boyHair)" stroke="#0F172A" strokeWidth="2" />
              {/* Sideburns */}
              <rect x="32" y="24" width="6" height="18" rx="2" fill="url(#boyHair)" />
              <rect x="82" y="24" width="6" height="18" rx="2" fill="url(#boyHair)" />
            </g>
          )}

          {/* ================= ROBLOX CLASSIC FACE DECALS ================= */}
          {isGirl ? (
            /* Cute Roblox Girl Face ("Super Happy" face decal style) */
            <g id="robloxGirlFace">
              {/* Big Expressive Anime Eyes with sparkles */}
              <ellipse cx="48" cy="46" rx="4.5" ry="5.5" fill="#0F172A" />
              <circle cx="46.5" cy="44" r="1.8" fill="#FFFFFF" />
              <circle cx="50" cy="48" r="1" fill="#FFFFFF" />

              <ellipse cx="72" cy="46" rx="4.5" ry="5.5" fill="#0F172A" />
              <circle cx="70.5" cy="44" r="1.8" fill="#FFFFFF" />
              <circle cx="74" cy="48" r="1" fill="#FFFFFF" />

              {/* Cute Eyelashes */}
              <path d="M44 42 L41 40" stroke="#0F172A" strokeWidth="1.8" strokeLinecap="round" />
              <path d="M76 42 L79 40" stroke="#0F172A" strokeWidth="1.8" strokeLinecap="round" />

              {/* Rosy Blush */}
              <circle cx="43" cy="53" r="3.5" fill="#FB7185" fillOpacity="0.75" />
              <circle cx="77" cy="53" r="3.5" fill="#FB7185" fillOpacity="0.75" />

              {/* Sweet Open Smile */}
              <path
                d="M53 53 Q60 63 67 53 Z"
                fill="#EF4444"
                stroke="#0F172A"
                strokeWidth="2.2"
                strokeLinejoin="round"
              />
            </g>
          ) : (
            /* Classic Roblox Boy Smile ("Winning Smile" or "Classic Smile") */
            <g id="robloxBoyFace">
              {/* Classic Oval Blocky Eyes */}
              <ellipse cx="48" cy="46" rx="3.5" ry="5" fill="#0F172A" />
              <ellipse cx="72" cy="46" rx="3.5" ry="5" fill="#0F172A" />
              {/* Catchlights */}
              <circle cx="47" cy="44" r="1.5" fill="#FFFFFF" />
              <circle cx="71" cy="44" r="1.5" fill="#FFFFFF" />

              {/* Determined Eyebrows */}
              <path d="M43 38 Q48 37 53 40" stroke="#0F172A" strokeWidth="2.5" strokeLinecap="round" />
              <path d="M67 40 Q72 37 77 38" stroke="#0F172A" strokeWidth="2.5" strokeLinecap="round" />

              {/* Confident Classic Roblox Smile */}
              <path
                d="M50 54 Q60 64 70 54"
                stroke="#0F172A"
                strokeWidth="3.2"
                strokeLinecap="round"
                fill="none"
              />
            </g>
          )}

          {/* ================= EQUIPPED HATS & ACCESSORIES ================= */}
          {equippedHat === 'golden_crown' && (
            <g transform="translate(60, 16)">
              <polygon points="-16,0 -20,-14 -10,-8 0,-16 10,-8 20,-14 16,0" fill="#FACC15" stroke="#CA8A04" strokeWidth="1.5" />
              <circle cx="0" cy="-6" r="2.5" fill="#EF4444" />
            </g>
          )}
          {equippedHat === 'grad_cap' && (
            <g transform="translate(60, 16)">
              <polygon points="0,-12 24,-4 0,4 -24,-4" fill="#0F172A" stroke="#334155" strokeWidth="1.5" />
              <rect x="-8" y="-4" width="16" height="8" fill="#1E293B" />
              <line x1="0" y1="-4" x2="18" y2="6" stroke="#FACC15" strokeWidth="2" />
            </g>
          )}
          {equippedHat === 'ninja_headband' && (
            <g>
              <rect x="33" y="32" width="54" height="7" rx="2" fill="#DC2626" stroke="#0F172A" strokeWidth="1.5" />
              <circle cx="60" cy="35.5" r="2.5" fill="#FFFFFF" />
            </g>
          )}
        </g>
      </svg>
    </div>
  );
};
