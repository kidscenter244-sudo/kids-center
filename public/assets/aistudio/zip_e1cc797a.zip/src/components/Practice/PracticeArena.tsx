import React, { useState } from 'react';
import { Zap, Heart, Sparkles, CheckCircle2, Play, ArrowLeft, Calculator, PlusCircle } from 'lucide-react';
import { StudentProfile } from '../../types';
import { sounds } from '../../services/soundEffects';
import confetti from 'canvas-confetti';

interface PracticeArenaProps {
  profile: StudentProfile;
  onRestoreHeart: (xpGain: number) => void;
}

interface MiniDrill {
  id: string;
  title: string;
  category: string;
  icon: string;
  description: string;
  questions: {
    q: string;
    choices: string[];
    answer: string;
  }[];
}

const MATH_DRILLS: MiniDrill[] = [
  {
    id: 'drill-add-sub',
    title: 'Rapid Column Add & Subtract',
    category: '1 & 2 Digits',
    icon: '⚡',
    description: 'Instant vertical mental math to sharpen mental Soroban beads.',
    questions: [
      { q: '7 - 3 + 4 = ?', choices: ['8', '7', '9', '6'], answer: '8' },
      { q: '9 - 5 + 6 = ?', choices: ['10', '11', '9', '8'], answer: '10' },
      { q: '14 - 8 + 7 = ?', choices: ['13', '12', '14', '15'], answer: '13' },
      { q: '25 - 12 + 10 = ?', choices: ['23', '21', '25', '22'], answer: '23' },
    ],
  },
  {
    id: 'drill-mul',
    title: 'Instant Mental Multiplication',
    category: 'Times Tables & Double Digits',
    icon: '✖️',
    description: 'Rapid-fire 2 digits multiplied by 1 digit and 2 digits by 2 digits.',
    questions: [
      { q: '15 × 6 = ?', choices: ['90', '85', '95', '80'], answer: '90' },
      { q: '24 × 4 = ?', choices: ['96', '92', '98', '86'], answer: '96' },
      { q: '35 × 3 = ?', choices: ['105', '95', '115', '100'], answer: '105' },
    ],
  },
  {
    id: 'drill-div',
    title: 'Mental Division Reflexes',
    category: 'Clean Integer Division',
    icon: '➗',
    description: 'Quick division for double and triple-digit dividends.',
    questions: [
      { q: '84 ÷ 4 = ?', choices: ['21', '22', '19', '24'], answer: '21' },
      { q: '96 ÷ 8 = ?', choices: ['12', '14', '11', '13'], answer: '12' },
      { q: '144 ÷ 12 = ?', choices: ['12', '11', '13', '14'], answer: '12' },
    ],
  },
];

export const PracticeArena: React.FC<PracticeArenaProps> = ({ profile, onRestoreHeart }) => {
  const [activeDrill, setActiveDrill] = useState<MiniDrill | null>(null);
  const [drillIndex, setDrillIndex] = useState(0);
  const [selectedChoice, setSelectedChoice] = useState<string | null>(null);
  const [isChecked, setIsChecked] = useState(false);
  const [drillCompleted, setDrillCompleted] = useState(false);

  const startDrill = (drill: MiniDrill) => {
    sounds.playClick();
    setActiveDrill(drill);
    setDrillIndex(0);
    setSelectedChoice(null);
    setIsChecked(false);
    setDrillCompleted(false);
  };

  const currentQ = activeDrill?.questions[drillIndex];

  const handleConfirmAnswer = () => {
    if (!currentQ || !selectedChoice || isChecked) return;
    setIsChecked(true);

    if (selectedChoice === currentQ.answer) {
      sounds.playCorrect();
    } else {
      sounds.playIncorrect();
    }
  };

  const handleNext = () => {
    if (!activeDrill) return;

    if (drillIndex < activeDrill.questions.length - 1) {
      setDrillIndex((prev) => prev + 1);
      setSelectedChoice(null);
      setIsChecked(false);
    } else {
      // Completed drill! Restore heart!
      setDrillCompleted(true);
      sounds.playFanfare();
      onRestoreHeart(25);

      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#22c55e', '#3b82f6', '#f59e0b', '#ec4899'],
      });
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 text-left select-none">
      {/* Header Info */}
      <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700 rounded-3xl p-6 sm:p-8 text-white shadow-xl mb-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-xs text-xs font-black uppercase mb-2">
            <Zap className="w-3.5 h-3.5 text-amber-300" />
            <span>Free Practice Arena</span>
          </div>
          <h2 className="font-heading font-black text-2xl sm:text-3xl mb-1">
            Recharge Hearts with Mental Drills!
          </h2>
          <p className="text-white/80 text-xs sm:text-sm font-semibold max-w-md">
            Practice here without losing hearts. Complete each drill to restore +1 energy heart and earn +25 XP!
          </p>
        </div>

        {/* Heart Status */}
        <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/20 flex items-center gap-3 shrink-0">
          <Heart className="w-8 h-8 fill-rose-400 text-rose-400 animate-pulse" />
          <div>
            <p className="text-[10px] font-black uppercase text-white/70">Energy Status</p>
            <p className="font-heading font-black text-xl">{profile.hearts} / {profile.maxHearts} Hearts</p>
          </div>
        </div>
      </div>

      {/* Drill Player Mode */}
      {activeDrill && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-slate-200 shadow-xl mb-6 animate-in zoom-in-95 duration-200">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-6">
            <button
              onClick={() => setActiveDrill(null)}
              className="text-xs font-bold text-slate-500 hover:text-slate-800 flex items-center gap-1 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Drills</span>
            </button>
            <span className="text-xs font-black text-slate-500 uppercase">
              {activeDrill.title} • Q{drillIndex + 1}/{activeDrill.questions.length}
            </span>
          </div>

          {!drillCompleted && currentQ ? (
            <div className="max-w-md mx-auto flex flex-col items-center text-center">
              <span className="text-4xl mb-3">{activeDrill.icon}</span>
              <h3 className="font-mono font-black text-3xl sm:text-4xl text-slate-800 mb-6 tracking-wider">
                {currentQ.q}
              </h3>

              {/* Multiple choice options */}
              <div className="grid grid-cols-2 gap-3 w-full mb-6">
                {currentQ.choices.map((choice) => {
                  const isSelected = selectedChoice === choice;
                  const isRight = choice === currentQ.answer;

                  let btnStyle = 'border-slate-200 hover:border-blue-400 text-slate-800';
                  if (isSelected) {
                    btnStyle = 'border-blue-500 bg-blue-50 text-blue-900 shadow-md';
                  }
                  if (isChecked) {
                    if (isRight) {
                      btnStyle = 'border-emerald-500 bg-emerald-50 text-emerald-950 font-black';
                    } else if (isSelected && !isRight) {
                      btnStyle = 'border-rose-500 bg-rose-50 text-rose-950';
                    }
                  }

                  return (
                    <button
                      key={choice}
                      disabled={isChecked}
                      onClick={() => {
                        sounds.playClick();
                        setSelectedChoice(choice);
                      }}
                      className={`py-4 rounded-2xl border-2 font-mono text-xl font-black transition-all cursor-pointer ${btnStyle}`}
                    >
                      {choice}
                    </button>
                  );
                })}
              </div>

              {/* Action Button */}
              {isChecked ? (
                <button
                  onClick={handleNext}
                  className="w-full py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-white font-heading font-black text-sm uppercase shadow-[0_4px_0_#059669] cursor-pointer"
                >
                  {drillIndex < activeDrill.questions.length - 1 ? 'Next Question' : 'Complete Drill & Collect Heart'}
                </button>
              ) : (
                <button
                  disabled={!selectedChoice}
                  onClick={handleConfirmAnswer}
                  className="w-full py-3.5 rounded-2xl bg-blue-500 hover:bg-blue-600 text-white font-heading font-black text-sm uppercase shadow-[0_4px_0_#2563eb] disabled:opacity-50 cursor-pointer"
                >
                  Confirm Answer
                </button>
              )}
            </div>
          ) : (
            /* Drill Complete Card */
            <div className="text-center py-6">
              <div className="w-16 h-16 mx-auto rounded-3xl bg-emerald-100 flex items-center justify-center mb-3">
                <Heart className="w-8 h-8 fill-rose-500 text-rose-500 animate-bounce" />
              </div>
              <h3 className="font-heading font-black text-2xl text-slate-800 mb-1">
                +1 Heart Restored! ❤️
              </h3>
              <p className="text-xs sm:text-sm font-bold text-slate-500 mb-5">
                You refreshed your mental math reflexes and earned +25 XP!
              </p>
              <button
                onClick={() => setActiveDrill(null)}
                className="py-3 px-8 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-white font-black text-sm uppercase shadow-[0_4px_0_#059669] cursor-pointer"
              >
                Back to Arena
              </button>
            </div>
          )}
        </div>
      )}

      {/* Available Drill Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {MATH_DRILLS.map((drill) => (
          <div
            key={drill.id}
            onClick={() => startDrill(drill)}
            className="p-5 rounded-3xl bg-white border-2 border-slate-200 hover:border-blue-400 hover:shadow-lg transition-all cursor-pointer flex flex-col justify-between group"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-3xl group-hover:scale-110 transition-transform">{drill.icon}</span>
                <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-blue-100 text-blue-800">
                  {drill.category}
                </span>
              </div>
              <h4 className="font-heading font-black text-lg text-slate-800 mb-1 leading-snug">
                {drill.title}
              </h4>
              <p className="text-xs text-slate-500 font-semibold mb-4 leading-relaxed">
                {drill.description}
              </p>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
              <span className="text-xs font-black text-rose-600 flex items-center gap-1">
                <Heart className="w-3.5 h-3.5 fill-rose-500" />
                <span>+1 Heart</span>
              </span>
              <button className="text-xs font-black text-blue-600 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                <span>Practice</span>
                <Play className="w-3 h-3 fill-blue-600" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
